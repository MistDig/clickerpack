#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    vec4 viewPosition = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * viewPosition;

    // World display vertices already contain entity transforms. Global ModelViewMat is
    // the client's camera rotation (LevelRenderer -> RenderType dynamic transforms).
    // 254 tags dashboard primitives; 253 tags the locally animated cursor.
    bool ironlineUi = false;
    bool ironlineCursor = false;
#if !defined(IS_GUI)
    ironlineCursor = abs(Color.a * 255.0 - 253.0) < 0.25;
    ironlineUi = (abs(Color.a * 255.0 - 254.0) < 0.25 || ironlineCursor)
        && abs(ProjMat[3][3]) < 0.001;
    if (ironlineUi) {
        float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
        float halfHeight = max(4.95, 8.5 / max(aspect, 0.001));
        vec2 halfCanvas = vec2(halfHeight * aspect, halfHeight);
        // Entity vertices are camera-relative. Undo camera translation as well as rotation.
        // CameraOffset is the NEGATIVE fractional camera position (stock terrain.vsh).
        vec3 cameraPosition = vec3(CameraBlockPos) - CameraOffset;
        vec3 worldPosition = Position + cameraPosition;
        vec2 logicalPosition = worldPosition.xy - vec2(0.0, 65.69);
        if (ironlineCursor) {
            // Camera rotation is inverse(Ry(pi-yaw) * Rx(-pitch)). No network wait.
            float yawDelta = degrees(atan(ModelViewMat[2].x, ModelViewMat[0].x));
            float pitch = degrees(atan(ModelViewMat[1].z, ModelViewMat[1].y));
            // Green encodes the last server player yaw in 16 sectors. It only
            // identifies front third-person; motion still comes from local rotation.
            float playerYaw = round(Color.g * 255.0) * 22.5;
            float cameraDifference = mod(yawDelta - playerYaw + 180.0, 360.0) - 180.0;
            if (length(cameraPosition - vec3(0.0, 65.62, 0.0)) > 0.5
                && abs(cameraDifference) > 90.0) {
                yawDelta = mod(yawDelta, 360.0) - 180.0;
                pitch = -pitch;
            }
            float gain = round(Color.r * 255.0) * 0.001;
            logicalPosition += vec2(clamp(yawDelta * gain, -7.8, 7.6),
                clamp(-pitch * gain, -4.3, 4.2));
        }
        // Stabilize depth as well as XY so turning cannot clip dashboard primitives.
        gl_Position = ProjMat * vec4(worldPosition - vec3(0.0, 65.62, 0.0), 1.0);
        gl_Position.xy = logicalPosition / halfCanvas * gl_Position.w;
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    if (ironlineUi) {
        // Screen content must not fade with world fog; it already has explicit full-bright metadata.
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    }
#else
    vertexColor = Color;
#endif
    // 254 is an identifying tag, not intended translucency.
    if (ironlineUi) vertexColor.a = 1.0;
    if (ironlineUi && ironlineCursor) vertexColor = vec4(1.0);
    texCoord0 = UV0;
}
